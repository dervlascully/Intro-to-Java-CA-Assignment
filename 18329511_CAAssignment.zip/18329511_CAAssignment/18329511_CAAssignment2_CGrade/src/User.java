public interface User {
    String getName();

    void setName(String name);

    public String getEmail();

    public void setEmail(String email);

    public int getAge();

    public void setAge(int age);
}
